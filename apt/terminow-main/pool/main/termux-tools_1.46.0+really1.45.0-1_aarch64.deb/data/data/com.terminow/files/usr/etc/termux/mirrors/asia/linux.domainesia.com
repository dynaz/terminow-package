# This file is sourced by pkg
# TermiNow | https://dynaz.github.io/terminow-package/apt
WEIGHT=1
MAIN="https://dynaz.github.io/terminow-package/apt/terminow-main"
ROOT="https://dynaz.github.io/terminow-package/apt/terminow-root"
X11="https://dynaz.github.io/terminow-package/apt/terminow-x11"
